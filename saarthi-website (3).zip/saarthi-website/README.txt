Saarthi download website

index.html is a single complete file: the HTML, CSS and JavaScript are all inside it.
It works when opened on its own (double tap in a browser) and on any hosting.

GO LIVE
GitHub Pages: create a public repository, upload index.html, then Settings > Pages > Branch: main, folder: / (root).
Netlify / Cloudflare Pages: drag and drop this folder.
cPanel: upload index.html into public_html.

CHANGE THE DOWNLOAD LINK
Search index.html for 12QGmzff1E7yVk8YbHC2pBYtVOwVxBZ4_ and replace it with your new Google Drive file ID (3 places).
The Drive file must be shared as: Anyone with the link (Viewer).
